


Lorcan Ríordan born 1448DR (Year of Neomen Swords) grew up in the quiet town of Secomber, second son to a working class family. His father Keane was a drunkard, but kind and functional. Always had work, and never shirked his responsibilities for a day at the pub. His mother Dara was a maid, cleaning houses for the wealthy. 

His brother, Colm, was a singer, and a star in the making. But he gave it up to chase another dream, and moved to Waterdeep (1464DR), where he joined the House of Good Spirits as a brewer. About a year later, rumors began about Colm having joined the Lord’s Alliance or Zentharim and then suddenly all contact with him ceased.  

After a couple years, believing their eldest son must surely have succumbed to some tragedy, his parents grew older rapidly, as halflings tend to do. Whether it was for their age or their grief, death eventually took them both (1468DR), and the much younger son Lorcan was left with the house where he lived for many years he found and met his love, Mara. She made jewelry for a living, though the quality was that of a lovely but talentless craftswoman at a flea market. They wed in the spring, and after some years (1471DR), they tried for a child. Tragedy struck again as Mara and the baby were lost during childbirth. Lorcan was devastated. In his grief, he let the house fall into disrepair, and eventually sold the place because rot held too many memories of those he lost. The only thing he kept was one earring of Mara’s favorite set - ones she loved far too much to ever sell to anyone. Lorcan kept the left. She was buried with the right.

 By 1476DR the much beloved Lord of Secomber passed and by the Fall of the same year, the Hobgoblin raids began. Without having much to defend themselves with, the townsfolk of Secomber became defacto slaves to the vicious Urshani clan, and life in the once beautiful town Lorcan knew as home became impossible. 

On a cold night one winter, Lorcan was set upon by a few well-known and connected drunken ruffians who wanted to rob him. Poverty had overtaken Secomber to where, for most, crime had become the only way. They snatched and stole his lone earring and made off into the night. But Lorcan followed them to their hideout. The earring had zero value to anyone other than Lorcan. But to him, it was invaluable. 

  He waited until the dead of night when all was still and quiet. He broke into their house and searched for the earring. At last, he found it and he was so overcome with joy that he leapt in the air. But in doing so, he knocked over a gas lantern which crashed to the ground. Lorcan bolted, and ran as hard and as fast as he could, lest he be caught. 

  He didn’t look back until he was absolutely sure he wasn’t followed. When he did, though, he was overcome with grief. He could see the flames blazing out of control in the distance. He could smell the pine burning. What had he done? What if they knew who he was? Those men were connected, and Lorcan had just torched their hideout. They were going to come for him. 
  
Lorcan fled to Waterdeep (1480DR) where he hoped to hide within the mass of bodies that made up the lower city’s overpopulated poor district. He blended wonderfully. And over the years, he learned that his remarkably small size came with advantages. He learned to steal to survive, and on occasion, even worked as a burglar, though never more than once for the same benefactor, for fear that he may be connected back to the men he killed. 

  Ten years have now passed (1491DR). The weather is changing violently. Strong storm surge and violent random lightning has made life in the lower city of Waterdeep again, impossible for Lorcan. And then, an unexpected letter.

A handwriting familiar to him in prose which ends simply with “Go North.”







 # Lorcan Riordan — Stage 1 Veilbound Unlock#
 
 
## "The Ledger"
### Location: Lagrella's Private Study | Session 6

---

## Setup & Trigger

While the party is occupied — Thrane at the obsidian orb, Vash 
examining the Burnt Journal, Róisin and Zuha being tended to — 
Lorcan drifts to the edges of the room as is his nature.

A glint of light catches his eye near the base of a worktable 
in the far corner of the study. Small. Catching the light. His 
instinct is professional — anything small and glinting is worth 
investigating.

He crosses the room and finds a single earring on the floor. 
Nothing like Mara's. Cheaper. Cruder. Likely belonging to one 
of Lagrella's victims or perhaps Lagrella herself.

It means nothing.

Except the act of picking it up does.

---

## DM Note — Pass to Lorcan's Player (Written or Whispered)

*"The earring is cold. Colder than the room. And then the smell 
hits you — not this room. Pine. Smoke. A winter night in Secomber. 
You can hear your own boots on cobblestone."*

*Then the world goes quiet.*

---

## The Vision (DM Narration to Lorcan's Player Only)

The Veil doesn't reconstruct memory cleanly. It works in 
fragments. Impressions.

You're back on that street. The fire is in the distance — orange 
against a dark winter sky. You can feel the cold on your face. 
Hear your own breathing. The sound of your heart.

And then the whispers begin.

Not words. Not yet. But shaped like voices. Multiple voices. 
And they are not in pain. They are not accusatory.

If anything — they sound confused.

The account you have been carrying for over a decade. The weight 
of men you believed you burned alive in Secomber. The guilt that 
drove you from everything you knew and made you into what you 
became in Waterdeep.

The Veil is showing you its ledger.

And the numbers do not add up the way you thought.

---

## What the Party Sees

Nothing dramatic. 

Lorcan crouched near a worktable in the far corner of the study. 
Perfectly still. Staring at something in his closed fist.

Thirty seconds. Perhaps a minute.

Then he blinks. Stands. Pockets whatever he found without a word.

---

## Mechanical Manifestation

Shortly after — in the next moment of tension or during the walk 
back through the caves — something quietly shifts for Lorcan.

Shadows feel different. He is aware of the edges of dim light in 
a way that feels less like vision and more like *presence*.

His Stage 1 Stealth advantage in dim light and darkness does not 
announce itself. It does not feel like a power he has gained.

It feels like something that was always there.

And just woke up.

---

## What This Moment Is NOT

- This is not about Mara. Not yet.
- This is not absolution. The Veil does not forgive.
- This is not a answer. It is a question.

The guilt Lorcan built his entire​​​​​​​​​​​​​​​​


Who is this writer that seems familiar to him? 

What could be North?

What does he have to lose?

  

  

For your eyes only.