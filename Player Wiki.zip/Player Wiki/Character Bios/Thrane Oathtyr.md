

  

The story of Thrane Oathtyr is one of fallen grace and a desperate, bloody climb toward redemption. Born in Helm’s Hold (1462DR) with the light blue hue of celestial blood in his veins, he was destined for the light—until the light became a conflagration.

 The House of Oathtyr was legendary, boasting a lineage that stretched back to the upper planes. As a child, Thrane was a living icon of nobility. By the age of twelve, his father—seeking to sharpen the "divine steel" of his son—sent him to train alongside the High Priest’s Guard. Under the tutelage of the realm’s finest masters, Thrane learned that a Paladin was not just a warrior, but a shield for the weak.

By eighteen, he had officially joined the Order of the Watcher, swearing his life to Helm(1478DR). He became the Order's rising star: disciplined, powerful, and seemingly incorruptible. 

This was during the aftermath of what is known as the Spellplague. A period following the assassination of Mystra by Shar and Cyril where the weave was thrown into utter chaos. Magic’s users throughout the lands of Toril (The planet we are on) were afflicted by all kinds of illnesses leading to madness or death. The Helmites however, having been granted their magic abilities through the divinity of Helm himself remained unaffected. This turned Helm’s Hold into a safe haven for many, and refugees came in never ending droves. However, this led to an eventual uprising when it was discovered that the Prophet Rohini, who had been the main leader of the city at that time, was actually in the services of Asmodeus. This marked the turning point for the Order of the Watcher transforming them into the Order of the Gilded Eye  (Circa 1479DR)

The turning point came during his twenty-third year(1482DR). Thrane’s unit was dispatched to the village of Connyberry to repel a massive warband of Orcs and cultists. These cultists were discovered to be members of the Black Earth, a cult of elementalist dedicated to re-instating an ancient temple below the city of Helm’s Hold. The battle was a meat grinder. Thrane watched his mentors fall one by one; he saw the light fading from the eyes of his brothers-in-arms.

As the enemy closed in for the final slaughter, something snapped within Thrane. It wasn't just courage; it was a volcanic eruption of righteous fury. He called upon every ounce of his celestial heritage and Helm’s divinity, unleashing a "Celestial Smite" of such magnitude that the sky itself seemed to fracture.

The Aftermath:

When the blue light cleared, the enemies were ash. But so was Connyberry. The blast had leveled the village. Amidst the charred remains of the invaders lay the bodies of nearly a hundred innocent civilians—families he had sworn to protect. The silence that followed was louder than any battle cry.

The Gilded Eye cast him out, stripping him of his rank and branding him an Oathbreaker. For years, Thrane wandered in a fugue of guilt, his divine powers flickering like a dying candle.

  He eventually found himself at the temple of Tyr - the Maimed God of Justice, inside the Halls of Justice in Waterdeep. Thrane didn't pray for forgiveness—he knew he didn't deserve it. Instead, he prayed for Retribution.

  "I have taken a hundred innocent lives," Thrane whispered to the cold stone altar. "Let me stay in this world until I have balanced the scales. Two hundred monsters for every one soul I extinguished."

  Tyr, a god who understands the heavy cost of justice and the weight of a scarred soul, answered. He didn't restore Thrane’s "holy" light; instead, he granted him a harsher, colder power—the strength to hunt those who truly deserve death.

Now thirty-two(1491DR), Thrane Oathtyr is a man of grim shadows and heavy plate. He has aligned himself with the Harpers, utilizing their network of spies to find the most depraved villains across the Realms. He is a mercenary by trade, but a collector by nature. He keeps a meticulous tally etched into scars that line his arms. To date, he has sent hundreds of evil souls to the Hells, but by his own math, he still has a long way to go before his debt to Connyberry is paid.    

  Recently Harpers have been dispatched to the Dessarian Valley repeatedly to investigate strange happenings with the weather, which has been becoming more of an issue for a while now. Tales of lightning rising from the ground randomly, tornadoes of fire appearing seemingly out of nowhere, floods without the presence of rain and earthquakes racking the city of Waterdeep and the surrounding areas. These events seem to be culminating in strength and frequency the closer you get to the Dessarian Valley, and namely the Slumbering Hills. Reports of cultists in the area manipulating the weather have also grown in frequency. 

Thrane has now been dispatched to rendezvous with the Harper contact Endrith Vallivoe in the small city of Red Larch. His mission is to investigate the area, help anyone who may be in need of it and report back to his superiors. 

  On a side note: The Cult of the Black Earth, the ones Thrane chased into Connyberry that fateful day, were also known to be able to manipulate the weather.

Could this be a coincidence…

  NPCs Thrane would know about:

- Endrith Vallivoe: (human male, early 50s) Owner of Vallivoe’s Sundries in Red Larch (Harper Contact)
- [[Marlando Gaelkur]]: (dwarven male, mid 40s) Barber in Red Larch - also a counterfeiter who operates a “second hand” store after hours.
- Zuha Omentide: (Half-Orc female, early 30s) Member of the Lord’s Alliance working in conjunction with the mercenary groups sent from Waterdeep. Been charged as a pseudo protector of the area.
- Harbuk Tuthamar: (Human male, late 40s) Constable of Red larch.
- Dagon Hadthvar: (Elf male, early 200s) 2nd ranking Lieutenant of the Harpers of Waterdeep, your direct supervisor.

  

Interaction with Orith (Aasimar Druid of the party - Liam):

Thrane would know that an aasimar coming into awareness of his celestial bloodline is a delicate thing, and must not be forced. Thrane may have come into his abilities as a young boy, but there are some that are late bloomers and the aasimar, in general, are pretty rare. The  inheritance of the bloodline is not genetic, for example your parents probably were not aasimar(or atleast not both), as that would make you close to full celestial. But, your parents would not have been afraid due to their dedication to Helm. I would say for now let Orith come to you if he has concerns or questions. You may find interactions that stem from a “ya know what I mean..” mentality (Which would confuse Orith but might be a funny bit if handled delicately )

I don’t want Thrane telling Orith what he is, unless that’s what Orith wants. Let’s keep things organic.

  Character Notes for DM:

  Parents are both still alive, still nobility(your choice as to title/etc). 

However, When Thrane was kicked out of the Order of the Gilded Eye and being labeled an oathbreaker, he felt he brought massive shame upon his family and in his “exile” he cut ties with them to avoid having his shame effect their standing as nobles. He hasn’t had contact with them for a decade. The last time he saw them, they were in the crowd watching him being stripped of rank and title, then he left the city. The choice of whether his parents are actually ashamed of him, or if it’s just in his mind, I’ll leave for you to play with. 

Deep down, he just wants to feel worthy of being their son again, but he doesn’t believe there is any true path to his full redemption. He is on the redemption journey, but he believes that will only save his soul, not eliminate his shame. 

I would say that leaders of the Order would be important to him. He was a rising star, exceptional student, and was poised to be the next leader for the Order. His relationship with them would have been a very important thing to him, and his removal would have been devastating. For him, and the Order. A great “ending” from him would be doing something that actually redeems him to the point where he no longer is labeled an oathbreaker and is actually brought back into the Order.




# Thrane Oathtyr — Oath of the Indebted Unlock
## "The Last Image"
### Location: Lagrella's Private Study | Session 6

---

## Setup & Context

The party has entered Lagrella's private study.
She is gone.

What remains:
- The Burnt Journal
- The Diamond Crux
- Zuha Omentide — bound, alive
- Róisin — imprisoned, alive
- And on a pedestal in the center of the room —
  a floating dark obsidian orb pulsing with dying light,
  cycling through rapid landscape visions at a pace
  too fast to follow.

Above it, a sigil hangs in the air.

Thrane recognizes it immediately.

---

## The Identification

Thrane is the first to name what he's looking at.

The Black Earth. The Elemental Eye. Vrotha'kun.

He knows this sigil. He has known it since Connyberry.
He has been hunting what it represents for nine years.

The party looks to him. He gives them what they need 
to know — faction, threat, scale. The professional 
assessment of a Harper operative who has done this 
before.

What he doesn't give them is everything else.

---

## The Orb — Dying

The obsidian orb is failing. Without Lagrella's magic 
to sustain it the visions are already beginning to 
slow and fragment. The light inside it is dimming 
with each passing second.

The landscape visions cycle — too fast, too brief, 
none of them holding long enough to read clearly.

Hills. Water. Stone. Roads. Ruins.

The party gathers. Watches. Tries to make sense of 
what they're seeing before it's gone completely.

---

## The Last Image

The orb flickers.

The visions slow.

One image holds — just a fraction of a second longer 
than the others. Long enough to register. Long enough 
to be unmistakable to exactly one person in the room.

Burned timbers. 
A collapsed chapel. 
A village square open to the sky where a roof used to be.

Anonymous northern ruins to everyone in the room.

But Thrane knows every stone of it.

Then the orb goes dark.

Complete darkness. 
No flicker. No fade. 
Just gone.

---

## The Silence

This is where you stop narrating and watch.

The orb is dead. The room is quiet. 
Whatever Thrane's player does in this moment 
is the scene.

Give it space. Don't fill it.

---

## What the Party Sees

A man who just identified a dangerous enemy faction 
with professional precision —

Going somewhere else entirely.

Not dramatically. Not loudly. 

Just — gone behind his own eyes for a moment.
The kind of still that costs something to maintain.

They don't have a framework for it.
They know it means something.
They don't know what.

That gap is yours to protect for now.

---

## The Oath — Deepening

In the darkness behind the dead orb Thrane's Oath 
tightens around him like a vice.

Not a vision. Not a dream. Just the cold arithmetic 
of what he now knows.

Lagrella is heading to Connyberry.
To the ruins he made.
With the tools of the cult he failed to stop nine years ago.

The scales he has been trying to balance for nine years 
just got heavier.

The debt he carved into his own arms just got larger.

And the ruins he created — the monument to his greatest 
failure — are now someone else's resource.

His past is not behind him.

It is directly ahead.

---

## Mechanical Manifestation

The Oath of the Indebted deepens not in triumph 
but in weight.

The Ledger of the Damned feels different now.
The scars on his arms feel different now.

Not heavier exactly. 

More *purposeful*.

Tyr granted him the strength to hunt those who 
truly deserve death. That covenant just found 
its sharpest edge.

His subclass abilities don't announce themselves.
They settle into place the way certainty does —
quietly, completely, without asking permission.

---

## For the Improv Pilot — DM Note

Thrane's player is good. Trust that.

If he goes stoic — protect the silence.
If he asks questions — answer only what the 
party could reasonably know.
If he says nothing at all — that is the performance.

The party will react however they react.
Let them find it without engineering it.

Your only job in this moment is to deliver the 
vision cleanly —

And then get out of the way.

---

## The Unanswered Question — For the Table

Nobody in the party knows about Connyberry yet.

They saw ruins in a dying orb and watched their 
companion go somewhere unreachable for a moment.

They will ask eventually.
Or they won't.

Either way — Thrane carries it alone for now.

The Róisin thread — her proximity to Phandalin, 
her peripheral knowledge of Connyberry's history —
is a seed that belongs to those two players 
to discover in their own time.

Let them be people first.
Let the history find them when they're ready.

---

## What This Moment Is NOT

- This is not closure. There is no closure here.
- This is not motivation. He already had motivation.
- This is not a breakdown. Thrane doesn't get that luxury.

This is the moment a nine year old wound 
gets a new and specific direction.

The ruins he made are ahead of him.
The cult he failed to stop is using them.
The woman who escaped this room is walking 
toward everything he destroyed.

He will go there.
He will finish it.

Whether that finishes him is a question 
for another session.
