
Born in 1469DR in Silverymoon to the well respected Yesna family, Vash began life pampered. If there was an illustration to the phrase “Born with his butt in the butter” It would include Vash. 

The Yesna's, a wealthy and powerful family of mages and wizards, were depended on by the political forces of Silverymoon and the greater Silvery Marshes area. His father Vastraen was head Advisor of Ancient Magics to the high court of Alustriel, which meant he was mostly too busy to show any sort of guidance or tenderness to Vash as a child. His mother Mistrea travelled as High Mage to the court of Neverwinter. She also was hardly available. This situation left Vast to be raised and educated by a cornucopia of instructors,maids and servants.

Vash, finding his ability to use magic rather easily, just couldn't seem to get passionate or get a grasp of the other expectations put upon him by his family. He wasn’t lazy, just a bit clumsy with his words or reactions sometimes. His education continued without really any presence from his father or mother. The only true interaction with his parents came when they would scold him.

By the time Vash became a young adult, his attitude was the problem. His understanding of the world centered solely upon himself. He continuously would embarrass the family in the way he “socialized” with people. Always acting as if he was the most important person in the room, and others should treat as such.

Eventually his father had had enough. In a torrent of rage his father accompanied by his mother (a rare occasion) informed Vash that he would be moving out! Not just from the luxurious mansion he had grown up in, but from Silverymoon entirely. Vastraen even went so far as to have guards escort Vash to the city gates and stripped him of the family name. And so Vash was alone.  

That was in 1482DR. Since then, Vash renaming himself Tifone has traveled throughout the Northern edges of the realms, with the exception of a stint down on the Sword Coast. He’s been trying to regain his honor and his father’s name but he hasn’t figured it out yet.

Now 1491DR, the Sjever Plateau is being plagued by strange weather patterns and violent storms seemingly emerging out of nowhere. If Vash can discover what’s causing these unnatural events then maybe it could be his ticket home.



# Vash Tifone — Bladesinger Unlock
## "The Recognition"
### Location: Lagrella's Private Study | Session 6

---

## Setup & Atmosphere

The study has been turned over. The party is processing what 
they've found — the Burnt Journal, the Diamond Crux, the dying 
obsidian orb. The air is thick with the residue of months of 
necromantic work. Cold stone. Dark staining. The particular 
smell of a room where death has been practiced rather than 
simply witnessed.

Among Lagrella's effects — pushed to one side of the room, 
piled without care — are the belongings of her victims. 
Clothes. Personal effects. Tools. The accumulated debris of 
people who came here and didn't leave.

Vash is searching through it. Because of course he is.

---

## The Find

At first it's just another object in the pile.

But something pulls his eye to it before he consciously 
registers what he's looking at.

A longsword. Sheathed. Lying discarded among the debris like 
it means nothing — like whoever put it there either didn't 
know what they had or didn't care.

But it is immaculate.

In a room full of tainted, used, discarded things — this blade 
is pristine. It doesn't belong here. It has never belonged here.

---

## The Sequence — Three Beats

**Beat One — The Hum**

Vash's hand hasn't touched it yet.

He's close. Reaching. And the blade *hums*.

Not loudly. Not dramatically. A single clean musical note that 
cuts through the death atmosphere of the room like a knife 
through smoke. Brief. Almost questioning.

The party hears it. They turn.

*"Something just made a sound. It came from where Vash is 
standing. A bright, clean tone completely at odds with 
everything else in this room."*

---

**Beat Two — The Warmth**

His fingers close around the hilt.

*Pass to Vash's player or narrate quietly:*

*"The grip is warm. Not room temperature. Not body temperature. 
Warm the way something gets when it has been waiting. The warmth 
spreads from the hilt up through your hand, your wrist, your arm. 
Something in your chest responds to it before your mind does. 
Like a word you've forgotten how to say suddenly sitting on the 
tip of your tongue."*

---

**Beat Three — The Light**

He lifts it.

The blade clears the sheath and for just a moment — two seconds, 
maybe three — it emits a faint blue-white luminescence. Clean 
and cold and completely unlike anything Lagrella's magic has left 
in this room.

Then it fades.

The blade is just a blade again.

Except it isn't. And Vash knows it isn't.

---

## What the Party Sees

A clean sword glowing briefly in the hands of their wizard.

A bright musical note in a dead woman's study.

Vash's face in the moment the warmth hits him.

They don't have a framework for what they just witnessed. 
Neither does Vash entirely. But it happened in front of all 
of them and he would tell them all about it anyway.

---

## The Bladesong — First Involuntary Stir

Shortly after — perhaps as the party prepares to leave, 
perhaps in the first moment of tension on the way out —
Vash feels it.

Not a decision. Not a technique he was taught in a classroom 
paid for by his father's coin.

Something older than that. Something that was always his.

A hum at the base of his skull. A looseness in his limbs. 
The weight of the blade in his hand feeling less like an 
object and more like an extension.

The Bladesong doesn't announce itself.

It simply begins.

---

## For the Improv Pilot — DM Soft Prompt

If Vash's player freezes or looks to you for direction 
after the glow fades, offer sensation not instruction:

*"The warmth spreads from the hilt up through your arm. 
Something in your chest responds to it before your 
mind does."*

Then stop. Hand it back. See where he goes.

---

## The Unanswered Question — DM Reference Only

This blade is connected to Vash specifically.

Not to Bladesingers generally. Not to the Yesna family. 
To *him*.

How. Why. Who carried it before him and how it ended up 
in Lagrella's chambers among her victims' effects.

Do not answer this yet. Do not hint at it yet.

Plant it. Let it breathe. Vash has a great deal of personal 
development ahead of him before this thread is ready to pull.

When the time comes it will mean something.

For now it is simply a clean blade in a dirty room that 
woke up when he walked in.

That is enough.

---

## What This Moment Is NOT

- This is not his father's gift. Nobody paid for this.
- This is not the Yesna legacy. The blade doesn't know that name.
- This is not mastery. This is recognition.

The training he rejected was never the problem.
The weight of who was demanding it was the problem.

That weight isn't here.

Nobody is watching except his companions.
Nobody expects anything except what he chooses to give.

For the first time — the Bladesong is simply his.
