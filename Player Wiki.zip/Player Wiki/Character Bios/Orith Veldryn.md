

Thorium and Aelthara (parents) were blessed with a child in The Year of The Reborn Hero (1463DR) in the quiet Daleic town of Hap. Orith, found coddled in a basket of Hayflowers, seemed to be a gift given by the gods themselves.

 Enjoying a modest farmlife upbringing Orith became attuned with his surroundings at a young age. But, in addition to his affinity to the nature around him, the dreams came also. Premonitions of imminent changes in the weather, the bountifulness of the next crop and when to yield it, these visions seemed incredible gifts to Orith. His parents however urged Him to keep the dreams to himself.

In the spring of 1475DR the visits began. Hanalily, an attractive and gentle Dryad appeared to Orith in his dreams and began educating and guiding him. She eventually directed him to Raelast Vensru, a local Circle of the Land herbalist who began Orith’s instruction in the use of his more special gifts. Raelast also recommended the visions, as well as the visits from Hanalily remain secret.

By 1484DR the Sembian armies began marching on Daleland as part of the events of the Second Sundering. Orith, now a young man with a good understanding of magic and nature was searching for ways to help his community, while continuing to do his best to hide the true nature of his gifts. But the dreams had now turned from instructive premonitions to full blown nightmares. Visions of gale-force winds shrouded in lightning and stars literally falling from the sky as well as the death and destruction caused by them. Hanalily appeared to Orith in flesh for the first time while He recounted the dreams to Raelast. Her message was clear, “Sylvanus is calling you to get your family to safety, follow the path of the Mighty Oak and restore the Balance.”

In 1487DR the Sundering ended, and historic Myth Drannor had been completely destroyed by the stars. Orith’s visions had come true. By now with the help of Raelast, Orith and his family had safely moved into Cormyr on the outskirts of the mighty city of Arabel. The calling of Sylvanus became stronger and stronger with Orith and so, by the Spring of 1488DR Orith left his family and began following the call through the direction of his dreams and Hanalily.

Filled by the search for answers and a deep desire to one day be reunited with his family, Orith now finds himself on the Sjever Plateau and the dreams are getting worse again…



# Orith Veldryn — Circle of the Green Knight Unlock
## "What the Owl Carries"
### Location: First Long Rest After Session 6 Discoveries

---

## Setup & Context

Wherever the party takes their first long rest —
Lance Rock, the road back, Red Larch —
Orith sleeps.

He always dreams.
He has dreamed since childhood.
His dream space has always been sacred.

But for weeks now the laughing skull has been there.
Lagrella's mark on him. Her eyes behind his eyes.
The dreams that were once instructive and gentle
have become something to endure rather than receive.

He doesn't fully understand the mechanics of what 
was done to him. He knows the skull keeps appearing.
He knows somehow she has been watching through him.
He knows his sacred space has been violated.

Tonight something is different.

---

## The Dream Opens — The Skull

It starts the way it always starts now.

The laughing skull at the edges.
Not subtle. Not hiding.
Lagrella's mark asserting itself the moment 
his consciousness drops into sleep.

The dream space feels contaminated.
Heavy. Watched. Wrong in the particular way 
it has been wrong since she touched him.

The skull doesn't speak. It never speaks.
It just laughs. Silently. Persistently.
The way something laughs when it knows 
it has already won.

---

## The Struggle — CON Save

But tonight something else is also present.

At the very edges of the contaminated dream —
further out than the skull, quieter than the skull —
something warm. Something that smells like 
forest floor after rain. Like green things 
growing in dark soil.

Something that has been trying to get through
for a long time.

*This is where the CON Save happens.*

Not as a mechanical interruption but as a 
dramatic moment within the dream itself.

---

## DM Narration to Orith's Player:

*"You become aware in the dream that you have a choice.
The skull is loud and present and it has been here 
so long it almost feels like furniture.*

*But there is something else at the threshold.*
*Something waiting to be let in.*
*Something that cannot enter while the skull 
occupies this much space.*

*You can feel the effort it would take to push back.*
*To carve out enough room.*
*To make the channel clean.*

*Roll Constitution."*

---

## On a Failed Save:

The skull holds.
The warmth at the edges recedes.
The dream is just the skull again — 
laughing in the contaminated dark.

Orith wakes unrested despite the long rest.
The curse remains fully active.
Barkwing is perched nearby watching him 
with an expression that is somehow 
more serious than usual.

Something tried to reach him tonight.
It didn't get through.
But he felt it trying.

Plant this seed. It will matter next rest.

---

## On a Successful Save:

The skull doesn't disappear.
The mechanics won't allow that yet —
three consecutive saves still required 
to break it fully.

But it retreats.
Pushed back to the very furthest edges 
of the dream space.
Still present. Still watching.
But distant enough that the channel 
between here and somewhere green and ancient
cracks open.

Just enough.

---

## Barkwing Arrives

Not flying in.
Not landing.

Simply — there.

The way things in true dreams simply are.

Barkwing sits before Orith in the dream space
and something is different about him.
The mischievous energy — the Vash-hair-nesting,
the gleeful small chaos of him — is quiet.

His eyes are still his eyes.
But something else is looking through them.

Gentle. Ancient. Impossibly fond.

*Hanalily.*

Not speaking. Not yet.
Just present in the way she has always been present —
as guide, as warmth, as the specific safety 
of being known completely.

---

## The Inversion — She Enters Him

Orith reaches toward Barkwing instinctively —
the familiar motion of warging outward,
of sending his consciousness into his familiar.

But that is not what happens.

Barkwing steps forward and something flows 
the other direction entirely.

Hanalily — through Barkwing — enters Orith.

Not violently. Not without care.
The way light enters a room when a curtain 
is pulled back. 

Gentle. Complete. Inevitable.

His dream space fills with green.

---

## What Sylvanus Shows — The Vision Sequence

Sylvanus does not speak.
He has never spoken to Orith directly.
He communicates in the language he invented —

Imagery. Sensation. Emotional truth 
too large for words to carry cleanly.

---

**Image One — What Orith Has Been Seeing**

The undead. Lagrella's chambers. 
The wrongness of animated death.
The specific violation of necromancy 
against the natural order.

Orith knows this wrongness intimately.
He has been fixated on it.
Rightly. It is real. It is an affront.

But —

---

**Image Two — Pull Back**

The vision expands.

Not just Lagrella's chambers.
Not just Lance Rock.
Not just Red Larch.

The Dessarin Valley spread out below —
and the weather moving across it 
like something alive and angry and wrong.

Lightning rising from the ground.
Fire tornados appearing from nothing.
Earthquakes splitting stone.
Floods without rain.

The storms Orith has been following.
The signs that brought him here.
They were never just about one necromancer.

---

**Image Three — The Deeper Wrongness**

Below the valley. Below the storms.
Below even the tunnels beneath Red Larch.

Something ancient and imprisoned
pressing against the walls of its prison
from the other side.

Not undead. Not necromancy.
Something that makes necromancy look 
like a symptom rather than a disease.

Vrotha'kun.

Orith doesn't hear the name.
He feels what the name means.

An Abyssal presence of enormous scale
that has been patient for a very long time
and is becoming less patient.

The elemental chaos across the valley —
the cults, the weather, the cult activity —
all of it is pressure. All of it is preparation.
All of it serves something Orith hasn't 
fully looked at yet.

---

**Image Four — The Green Knight**

Finally —

A figure. 

Not Orith as he is.
Orith as he is becoming.

Armored not in metal but in the memory 
of every forest that has ever stood its ground.
Weapon in hand not as a last resort 
but as a first language.

The Green Knight doesn't wait for the corruption 
to come to the forest.

The Green Knight goes to meet it.

The calling Sylvanus placed in him as a child —
the dreams, the visions, Hanalily's guidance,
the years of following signs —

It was always building toward this.

Not a druid who tends and observes.
A knight who protects and acts.

---

## The Withdrawal

Hanalily withdraws gently.
The way warmth leaves a room gradually 
rather than all at once.

The skull is still at the edges.
The curse is still active.
The dream space is still not entirely clean.

But something has been planted in the 
contaminated soil that the skull 
cannot reach or comprehend.

Understanding.
Direction.
The specific clarity of knowing 
what you were made for.

---

## Waking

Orith wakes.

Barkwing is perched nearby.
Back to himself — or seemingly so.
Already eyeing whatever is closest 
to Vash with familiar intent.

But for just a moment —
a fraction of a second —
Barkwing's eyes find Orith's.

Something passes between them 
that has no name at the table.

Then Barkwing looks away.
Ruffles his feathers.
Returns to being exactly 
what he has always appeared to be.

---

## Perception Check — Party Awareness

If a party member is on watch and actively 
observing Orith during the dream:

**DC18 Perception**

On a success they notice:
Orith's eyes open briefly while he sleeps.
Not the eyes of someone waking.
Something else. A stillness behind them
that doesn't belong to sleep or waking.

Gone in a second.
Probably nothing.

File it away.

---

## Mechanical Manifestation

Orith wakes with the Circle of the Green Knight 
fully accessible.

The martial calling that has always been 
underneath his druidic nature
has a shape now. A purpose.
A direction that is larger than one enemy.

His weapons feel different in his hands.
Not heavier. More intentional.

The Force of Nature stirs somewhere 
beneath his consciousness —
not yet summoned, not yet needed,
but present the way certainty is present.

Waiting to be called.

---

## What This Moment Is NOT

- This is not about Lagrella. She is a symptom.
- This is not tunnel vision with a wider aperture.
  It is a fundamentally different way of seeing.
- This is not the end of his calling. 
  It is the beginning of understanding its scale.

The laughing skull is still in his dreams.
The curse is still active.
Lagrella is still out there.

But Orith knows now what he is walking toward
and it is so much larger than her.

Sylvanus didn't send him to the Dessarin Valley 
to stop a necromancer.

He sent him to stand between the world 
and what is trying to crack it open.

---

## DM Long Game Reference

The Mara thread belongs to Lorcan.
The blade thread belongs to Vash.
The Connyberry thread belongs to Thrane.

This — the scale of the true threat,
the understanding that arrived before 
anyone else in the party has it —

This belongs to Orith.

He carries it quietly until the moment 
it becomes relevant to share.

Plant seeds. Trust the player.
The Green Knight doesn't announce himself.

He simply stands in the way.

  

