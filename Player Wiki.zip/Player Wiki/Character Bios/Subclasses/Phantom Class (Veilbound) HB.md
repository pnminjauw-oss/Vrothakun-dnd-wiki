# # Rogue Archetype: Phantom (Veilbound)

*Many rogues who follow the Phantom archetype brush against death. Veilbound Phantoms linger in its shadow, drawing power from lingering spirits while slowly surrendering their hold on the world of the living.*

---

## Level Progression

| Rogue Level | Feature(s) |
|------------|------------|
| 3 | Whispers of the Dead, Wails from the Grave, Veil Points, Veil Stages |
| 5 | Hungering Shadows, Stage 3 Unlock |
| 9 | Tokens of the Departed, Veil Sustain, Stage 4 Unlock |
| 11 | Veil Techniques |
| 13 | Ghost Walk |
| 15 | Lingering Death |
| 17 | Death Knows No Bounds, Final Crossing |
| 20 | Avatar of the Veil |

---

### Whispers of the Dead (3rd Level)  
*Passive*  
When you finish a short or long rest, choose one skill or tool proficiency you lack. You gain that proficiency until you use this feature again.

---

### Wails from the Grave (3rd Level)  
**⚔️ Attack / Active**  
Immediately after you deal Sneak Attack damage to a creature on your turn, you can target a second creature within 30 feet.  

- The second creature takes necrotic damage equal to **half the number of Sneak Attack dice rolled** (rounded down).  
- **Uses:** A number of times equal to your proficiency bonus; all expended uses are regained after a long rest.

---

### Veil Points & Stages (3rd Level)  
*Passive / Tracking*  
**Veil Points (VP):** Maximum = proficiency bonus.  

- Gain 1 VP when you use **Wails from the Grave** or create a soul trinket.  
- Lose 1 VP at end of long rest if you have no trinkets.  
- Cannot gain more than 1 VP on a single turn.  

**Veil Stages:**

| Stage | VP Required | Unlock Level | Features |
|-------|------------|--------------|----------|
| **0 — Mortal Tether** | 0 VP | — | Fully anchored to the living world. No additional benefits or penalties. |
| **1 — Whispered Presence** | 1+ VP | 3rd | Advantage on Stealth in dim light/darkness; advantage on saving throws against being frightened; your presence feels faintly wrong. |
| **2 — Shadow-Touched** | 2+ VP | 3rd | Resistance to necrotic damage; vulnerability to radiant damage; no need to breathe; advantage on death saving throws. **Shadow Slip:** Bonus Action to move through one hostile creature’s space (difficult terrain, cannot end turn in that space, no opportunity attacks; once per turn). |
| **3 — Half-Bound Soul** | 3+ VP | 5th | Resistance to bludgeoning, piercing, slashing from nonmagical attacks; advantage on saving throws vs. charm/poison; no need to eat or drink. If you consume food or drink, it turns to ash and you must succeed on a DC 12 Constitution save or take poison damage equal to your proficiency bonus. Magic that detects undead senses you as both humanoid and undead. |
| **4 — Warden of the Veil** | Maximum VP | 9th | Creature type becomes undead in addition to humanoid; immunity to frightened; regain HP equal to proficiency bonus when reducing a creature to 0 HP; can expend 1 VP to drop to 1 HP instead of 0 (long rest recharge). Your reflection may fail to appear and footsteps are silent unless willed. |

---

### Hungering Shadows (5th Level)  
**⚡ Bonus Action / Active**  
When a combat encounter ends in which at least one creature died within 30 feet, you can gain 1 Veil Point. Once per short or long rest.

---

### Tokens of the Departed (9th Level)  
**🔮 Reaction / Active**  
When a creature dies within 30 feet, create a **soul trinket**.  

- While carrying at least one trinket: advantage on death saving throws and Constitution saving throws.  
- Expend a trinket to ask the spirit one question or gain advantage on **one attack roll, ability check, or saving throw**.

---

### Veil Sustain (9th Level)  
*Passive*  
When you expend a soul trinket, you may gain 1 Veil Point.

---

### Veil Techniques (11th Level)  
**⚡ Bonus Action / Active**  

- **Veil Step (1 VP):** Teleport up to 30 ft to dim light or darkness.  
- **Grave Strike (1 VP):** When you hit with Sneak Attack, convert half the Sneak Attack damage to necrotic and add your proficiency bonus.

---

### Ghost Walk (13th Level)  
**⚡ Bonus Action / Active**  
Assume spectral form for **1 minute**:  

- Flying speed 10 ft, hover  
- Attack rolls against you have disadvantage  
- Move through creatures and objects as difficult terrain  

**Uses:** Once per long rest

---

### Lingering Death (15th Level)  
**⚡ Reaction / Active**  
While at Stage 3 or 4:  

- Advantage on death saving throws  
- When reduced to 0 HP but not killed outright, expend 2 VP to drop to 1 HP  

**Uses:** Once per long rest

---

### Death Knows No Bounds (17th Level)  
*Passive*  
Wails from the Grave necrotic damage equals the **full number of Sneak Attack dice rolled**.

---

### Final Crossing (17th Level)  
*Passive / Choice*  
Choose permanently:  

- **Anchor to Life:** Maximum VP halved; cannot enter Stage 4; regain HP equal to Sneak Attack dice when reducing a creature to 0 HP.  
- **Embrace the Veil:** Permanently gain Stage 4 benefits; VP no longer decreases at long rest; cannot be resurrected except by *wish*.

---

### Avatar of the Veil (20th Level)  
**⚡ Active / Aura**  
While in Stage 3 or 4:  

- **Ethereal Mastery:** Move through creatures and objects without impediment; ignore difficult terrain and nonmagical barriers  
- **Veil-Infused Strikes:** Once per turn, when you hit with Sneak Attack, deal additional necrotic damage equal to **1d6 per Veil Point** you currently possess  
- **Aura of the Veil:** Enemies within 10 ft have disadvantage on **Wisdom (Perception) checks** and saving throws against fear; allies within 10 ft gain **resistance to necrotic damage**  

Your connection to the Veil is absolute, making you a **specter of vengeance** feared by both the living and the dead.