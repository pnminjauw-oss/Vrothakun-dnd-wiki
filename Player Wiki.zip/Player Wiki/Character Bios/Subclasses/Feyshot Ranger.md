# Ranger Archetype: Feyshot Conclave

Feyshot rangers are archers whose weapons are guided by the magic of the Feywild. Their arrows bend space, weave illusion, and disrupt the will of their enemies. Through supernatural precision and trick shooting techniques, a Feyshot controls the battlefield with elegance and unpredictability.

---

## Feyshot Archetype Features

| Ranger Level | Feature |
|--------------|---------|
| 3rd | Feyshot Techniques, Feyshot Magic |
| 5th | Arcane Enhancements (first access), Fey Barrage (Trick Shot unlock) |
| 7th | Fey Mark (Fey Court), +1 Trick Shot |
| 9th | Arcane Enhancement unlock |
| 10th | +1 Trick Shot |
| 11th | Arcane Efficiency + final Enhancement |
| 15th | Feywild Surge (Capstone) |

---

## 3rd-Level — Feyshot Techniques

You gain access to **Trick Shots**, specialized ranged weapon maneuvers fueled by Fey Arrow dice.

- Trick Shots only apply to ranged weapon attacks.  
- One Trick Shot per attack; Boost effects limited to one major debuff per target per turn.  

### Fey Arrow Dice

- Number of dice = proficiency bonus  
- Regain all dice on short or long rest  
- Fey Arrow die size by ranger level:

| Ranger Level | Fey Arrow Die |
|-------------|---------------|
| 3–9 | d6 |
| 10–17 | d8 |
| 18+ | d10 |

Using Fey Arrow Dice:  

- Roll one die when instructed by a Trick Shot or feature.  
- Damage type matches the triggering attack unless stated otherwise.  
- Roll separately for each creature affected.  

---

### Trick Shot Progression (Battlemaster Style)

| Ranger Level | Trick Shots Known | New Trick Shots This Level |
| ------------ | ----------------- | -------------------------- |
| 3            | 3                 | 3 (base set)               |
| 5            | 4                 | +1                         |
| 9            | 5                 | +1                         |
| 13           | 6                 | +1                         |

> You may swap one Trick Shot when gaining new Trick Shots.

**Example Trick Shots (Boosts included):**

- **Entangling Shot:** Strength save or restrained until start of next turn. Boost: If restrained, add Fey Arrow die as damage.  
- **Staggering Shot:** Constitution save or speed = 0, cannot take reactions. Boost: lasts until end of target’s next turn.  
- **Disarming Shot:** Strength save or drop one held item. Boost: drop all held items.  
- **Distracting Shot:** Next ally attack against target has advantage. Boost: target’s next saving throw until start of next turn at disadvantage.  
- **Piercing Shot:** Ignore half and three-quarters cover. Boost: Dex save or −2 AC until end of next turn.  
- **Bounding Shot:** Strength save or pushed 10 ft. Boost: knocked prone if fails.  
- **Explosive Arrow:** Each creature within 5 ft Dex save, take Fey Arrow die damage (half on success). Boost: radius becomes 10 ft.  
- **Feyfire Shot:** Dex save or attacks against it have disadvantage. Boost: add Fey Arrow die radiant damage.  
- **Misty Arrow:** After attack, teleport 10 ft. Boost: teleport 20 ft; gain advantage on next attack before end of turn.  
- **Shadowed Shot:** Wis save or blinded until start of next turn. Boost: take Fey Arrow die psychic damage; blinded until start of next turn.

> Note: Boosts cannot stack multiple major debuffs on the same target in one turn.

---

## 3rd-Level — Feyshot Magic

You gain additional spells that count as ranger spells but do not count against spells known:

| Ranger Level | Spell |
|-------------|-------|
| 3 | Faerie Fire |
| 5 | Misty Step |
| 9 | Haste |
| 13 | Greater Invisibility |
| 17 | Hold Monster |

---

## 5th-Level — Arcane Enhancements (First Access)

- You may now apply Arcane Enhancements to your Trick Shots.  
- Enhancements known: 2 at level 5, 3 at lvl 7, 4 at lv 9, 5 at lvl 11.
- Mechanics: Each enhancement costs 1 Fey Arrow die; only one enhancement per attack.  
- Example initial enhancements:  
	- Haunting Shot: WIS Save against Spell DC, on failure Frightened until the end of its next turn.
	- Illusive Shot: Attacks against you made by the target are done so at disadvantage until the start of your next turn
	- Charming Shot: Target makes a CON Save against your Spell DC, on failure target is Charmed until the end of it’s next turn.
	- Maddening Shot: Target takes additional Psychic damage equal to your Fey Arrow die + Proficiency Bonus
	- Twin Shot: You can target another creature within 15ft of the first, deal piercing damage equal to 1 Fey Arrow die + Proficiency Bonus

---

## 5th-Level — Fey Barrage (Trick Shot)

- Requirement: Ranged weapon attack  
- Effect: Spend 3 Fey Arrow dice to unleash Fey Barrage.  
- Area: Each creature within 15 ft of original target makes the Trick Shot saving throw.  
- Damage/Effect: Roll separate Fey Arrow die for each creature affected.  
- Boost: Spend 1 additional die to increase radius/add secondary effect.  
- Recovery: If any target reduced to 0 HP, regain 1 Fey Arrow die.  
- Restriction: Cannot hit the same target twice with multiple boosts in one turn.

---

## 7th-Level — Fey Mark (Fey Court)

Casting Hunter’s Mark allows designation of a Fey Mark.  

- Once per turn, when hitting a Fey Marked creature with a Trick Shot, you may choose one Fey Court effect after the attack hits but before damage is rolled.  
- Teleport limits: Fey Slip/teleport only once per Trick Shot per turn.

**Fey Court Options:**

- **Autumn Court — Precision and Decay:** extra damage = Fey Arrow die; disadvantage on first save against Trick Shot; teleport 10 ft.  
- **Winter Court — Icy Discipline:** extra cold damage = Fey Arrow die; speed −10 ft; teleport 10 ft.  
- **Spring Court — Growth and Renewal:** extra radiant damage = Fey Arrow die; next ally attack advantage; teleport 10 ft.  
- **Summer Court — Fire and Fury:** extra fire damage = Fey Arrow die; target cannot take reactions; teleport 10 ft.

---

## 9th-Level — Arcane Enhancement Unlock

- Gain 1 additional Arcane Enhancement (total known = 4).  
- Example new option: **Maddening Shot** (Fey Arrow die psychic damage).  

---

## 10th-Level — Trick Shot Unlock

- Gain 1 additional Trick Shot (total known = 5).  
- Can swap one Trick Shot when gaining a new one.

---

## 11th-Level — Arcane Efficiency

- Gain 1 additional Arcane Enhancement (total known = 5).  
- Arcane Efficiency: Once per turn, when you Boost a Trick Shot, you may apply one enhancement for free.  
- Full enhancement list now available: Haunting, Illusive, Maddening, Charming, and Twin Shot.

---

## 15th-Level — Capstone: Feywild Surge

- **Teleporting Shot:** When you hit a creature with a Trick Shot, you may teleport up to 30 ft to an unoccupied space you can see.  
- **Free Enhancement:** When using Teleporting Shot, apply one Arcane Enhancement you know without spending a Fey Arrow die.  
- **Fey Arrow Recovery:** If a creature is reduced to 0 HP by one of your Trick Shots this turn, you regain all expended Fey Arrow dice.  
- **Feywild Surge (1/long rest):** As a bonus action, unleash a surge centered on a target: all creatures within 15 ft make the saving throw for your triggering Trick Shot or take Fey Arrow die damage (half on success).

---

## Fey Arrow Die Tracker

- Maximum = proficiency bonus  
- Regain all dice on short or long rest