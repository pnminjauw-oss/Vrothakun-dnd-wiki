# Oath of the Indebted

## Sacred Oath

Paladins who swear the Oath of the Indebted are bound not by rebellion, but by failure. Having once broken or failed a sacred vow, they submit themselves to a harsher covenant—an eternal debt measured in blood and mercy. Each life taken in the name of justice deepens their burden; each act of healing lightens it.

Their bodies bear supernatural marks—scars, brands, or sigils—that record this debt. These marks shift and change as their ledger rises and falls.

Brutal in battle and relentless in compassion, they pursue redemption they believe they can never truly earn.

---

## Tenets of the Indebted

**Atonement Through Action.** I cannot undo my failure. I can only strive endlessly to outweigh it.  
**Suffering Has Purpose.** Pain borne willingly is sacred.  
**Protect the Innocent.** Others will not pay for my sins.  
**No Turning Away.** I will not avert my eyes from cruelty or tyranny.  
**No Final Forgiveness.** Redemption is not claimed—it is pursued.

---

## Oath Spells

You gain oath spells at the paladin levels listed in the Oath of the Indebted Spells table. See the Sacred Oath class feature for how oath spells work.

| Paladin Level | Spells |
|---------------|--------|
| 3rd | cure wounds, inflict wounds |
| 5th | lesser restoration, spiritual weapon |
| 9th | zone of truth, misty step |
| 13th | blight, revivify |
| 17th | destructive wave, greater restoration |

---

## Channel Divinity

When you take this oath at 3rd level, you gain the following two Channel Divinity options.

### Blood for Mercy

As a bonus action, you can expend any number of Debt Points. For each Debt Point spent, choose creatures you can see within 30 feet of you. The chosen creatures regain hit points equal to 1d8 + your Charisma modifier per Debt Point spent, divided among them as you choose.

### Judgment Without End

As an action, you present the marks of your covenant. For 1 minute, you emanate a 15-foot-radius aura of spectral chains that moves with you. The aura ends early if you are incapacitated.

When a hostile creature of your choice starts its turn in the aura, it must succeed on a Wisdom saving throw against your paladin spell save DC. On a failed save, until the start of its next turn:

- The creature has disadvantage on attack rolls against creatures other than you.
- If the creature willingly moves more than 10 feet away from you, its speed becomes 0 until the end of the turn.

The first time a creature affected by this aura hits you with an attack on its turn, you gain 1 Debt Point.

When a creature affected by this aura is reduced to 0 hit points, you gain 1 Debt Point.

---

## Ledger of the Damned
### 3rd-Level Oath of the Indebted Feature

You bear a supernatural tally of your unpayable debt. You gain Debt Points (DP), which represent the weight of your covenant.

- When you reduce a hostile creature to 0 hit points, you gain 1 Debt Point.
- When you restore hit points to another creature using a spell or class feature, you lose 1 Debt Point.
- You can gain no more than 1 Debt Point from the same creature per turn.
- You can have a maximum number of Debt Points equal to your paladin level.
- You lose all Debt Points when you finish a long rest.

### Burdened Power

While you have one or more Debt Points, you gain the following benefits:

**1+ DP.** You gain a +1 bonus to weapon damage rolls.

**5+ DP.** You have advantage on Charisma (Intimidation) checks and Strength ability checks.

**10+ DP.** When you hit with a weapon attack, the attack deals an extra 2d4 radiant or necrotic damage (your choice). This extra damage increases to 2d6 at 11th level and 2d8 at 17th level.

---

## Zeal of the Unyielding Witness
### 7th-Level Oath of the Indebted Feature

When a hostile creature you can see within 30 feet of you deals damage to a creature other than you, you can use your reaction to move up to half your speed toward that creature without provoking opportunity attacks and make one weapon attack against it. You must end this movement closer to the creature.

Hit or miss, you gain 1 Debt Point.

You can use this feature a number of times equal to your Charisma modifier (minimum of once). You regain all expended uses when you finish a long rest.

---

## Suffer in Silence
### 10th-Level Oath of the Indebted Feature

When you fail a saving throw, you can expend 2 Debt Points to reroll the saving throw. You must use the new result.

If the saving throw was made to resist damage, you have resistance to that damage until the end of your next turn.

---

## Scars That Shield
### 15th-Level Oath of the Indebted Feature

While you have 5 or more Debt Points, you have resistance to one damage type of your choice. You choose the damage type when you finish a long rest.

In addition, when a creature hits you with an attack, you can use your reaction to deal radiant or necrotic damage (your choice) to that creature equal to your Charisma modifier.

---

## Living Ledger
### 20th-Level Oath of the Indebted Feature

As a bonus action, you can assume the full burden of your covenant. For 1 minute:

- You do not lose Debt Points when you restore hit points to another creature.
- At the start of each of your turns, you gain 1 Debt Point, up to your maximum.
- When you hit with a weapon attack, the attack deals an extra 2d8 radiant or necrotic damage (your choice).
- You have advantage on attack rolls against creatures that are below half their hit point maximum.

Once you use this feature, you can’t use it again until you finish a long rest.