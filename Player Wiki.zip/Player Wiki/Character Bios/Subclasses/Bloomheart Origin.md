# 🌹 Bloomheart Sorcerous Origin — Canonical

Your magic flows from a mystical pendant containing six eternal rose essences. Each bloom represents a different arcane strain — protection, destruction, emotion, vitality, growth, and decay. At first, the garden chooses which rose blossoms within you. In time, you learn to command it.

Your rose pendant can be used as your spellcasting focus.

---

## Level 1 — Floral Manifestation

At the end of a long rest, roll a d6 to determine which Rose is **In Bloom** for the day. You gain that rose’s Passive Benefit and Petal Flare.

### Bloomheart Spells

| Sorcerer Level | Spells |
|----------------|--------|
| 1st | Thorn Whip, Entangle |
| 3rd | Lesser Restoration, Spike Growth |
| 5th | Plant Growth, Revivify |
| 7th | Aura of Life, Grasping Vine |
| 9th | Greater Restoration, Wall of Thorns |

---

## Level 1 — Thorn Shield

While you are not wearing armor and not wielding a shield, your Armor Class equals:

**13 + your Dexterity modifier**

---

## Level 1 — The Rose Pendant

**Petal Flare.** Once per turn, when a creature takes damage from one of your spells or fails a saving throw against one of your spells, you may apply your Petal Flare to one affected creature.

### Rose Essences — Table

| Roll | Rose                   | Passive Benefit                                                                                                                                                                                                  | Petal Flare                                                                                                  |
| ---- | ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| 1    | **Black — Withering**  | Each time you use Petal Flare, you take **1d4 necrotic (levels 1–9), 1d6 (levels 10–17), 1d8 (level 18+)** as the rose feeds on your life force.                                                                 | The target cannot regain hit points until the start of its next turn **and takes 1d6 + PB necrotic damage**. |
| 2    | **Blue — Tranquility** | When a creature is damaged by one of your spells, their speed is reduced by 10 ft until the start of their next turn.                                                                                            | The target must make a Strength check or is restrained until the start of its next turn.                     |
| 3    | **Red — Fury**         | When you deal fire damage with a spell, add your Charisma modifier to one damage roll of that spell.                                                                                                             | The target takes **1d6 + PB fire damage**.                                                                   |
| 4    | **Yellow — Vines**     | You have **advantage on Constitution checks and saving throws**.                                                                                                                                                 | The target has disadvantage on its next attack roll before the start of your next turn.                      |
| 5    | **Pink — Charm**       | You have **advantage on Charisma-based checks and saving throws**.                                                                                                                                               | The target cannot take reactions until the start of your next turn.                                          |
| 6    | **White — Renewal**    | When a spell you cast restores hit points to one or more creatures, choose one creature that regained hit points from that spell. That creature also gains temporary hit points equal to your proficiency bonus. | You or one ally within 30 feet gains temporary hit points equal to your proficiency bonus.                   |

---

## Level 1 — Experimental Bloom (d8 Bloom Surge Table)

Because your magic is self-taught, sometimes your bloom flares unpredictably. Whenever you roll a 1 on a spell attack, roll a 1d8 on the Bloom Surge Table. That spell has the following effect instead.

| Roll | Effect Type | Effect |
|------|------------|--------|
| 1 | Negative | **Thorn backlash:** You take 1d6 necrotic damage. |
| 2 | Negative | **Minor Bloom Misfire:** You cannot use a bonus action on your next turn. |
| 3 | Neutral | Thorn lash: One creature within 10 ft must make a Strength save or be pushed 5 ft away. |
| 4 | Neutral | Defensive bloom: You gain +2 AC until the start of your next turn. |
| 5 | Neutral | Fragrant mist: Allies within 5 ft gain +1 bonus to saving throws until your next turn. |
| 6 | Neutral | Petal distraction: One creature within 10 ft has disadvantage on its next attack roll. |
| 7 | Positive | Empowering bloom: Gain advantage on your next spell attack or saving throw. |
| 8 | Positive | Healing fragrance: You or one ally regain 1d6 HP. |

---

## Level 3 — Petal Step

When a creature hits you with an attack, you can use your reaction to dissolve into petals and teleport up to 30 feet to an unoccupied space you can see.

You can use this feature a number of times equal to your proficiency bonus, regaining all uses when you finish a long rest.

---

## Level 6 — Shifting Fragrance

Once per short or long rest, you can use a bonus action to **change which Rose is In Bloom**, selecting the rose of your choice.

---

## Level 14 — Fragrant Aura

As a bonus action, you radiate a magical fragrance in a 10-foot aura for 1 minute.

- Allies in the aura gain a +1 bonus to saving throws.  
- Enemies in the aura have disadvantage on attack rolls against creatures other than themselves.

Once you use this feature, you can’t use it again until you finish a long rest, unless you expend 3 sorcery points to activate it again.

---

## Level 18 — Sovereign Bloom

You have mastered the Eternal Garden.

- You may choose which Rose is In Bloom at the end of a long rest.  
- You may have two Roses In Bloom at the same time.  
- When you use Petal Flare, you may apply the effects of both active Roses to the same triggering creature.  
- You may activate Petal Flare twice per turn, but no more than once per spell.  
- At the start of your turn, if you have 0 sorcery points, you regain 2 sorcery points.