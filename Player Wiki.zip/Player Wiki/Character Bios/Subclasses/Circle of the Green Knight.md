# Druid Circle: Circle of the Green Knight

Druids of the **Circle of the Green Knight** are stalwart defenders of nature who take a more martial approach to protecting the forest. Blessed by the spirit of the green, they adapt to adversity, persevere, and wield metal weapons to defend their domain.

## Green Knight Origins

| d6 | Origin |
|---|---|
| 1 | A spirit of nature has incarnated within you, granting powers to manipulate the green. You serve as their protector. |
| 2 | Abandoned to the forest as a child, the green raised you to defend it. |
| 3 | You aspired to protect nature directly, rather than through activism or politics. |
| 4 | Scouted by another Green Knight at a young age, you learned the ways of nature as a squire. |
| 5 | Your village among the trees was destroyed by outsiders. Now you avenge the forest. |
| 6 | A chance encounter with wildlife inspired you to swear to protect nature. |

---

## Circle of the Green Knight Features

| Druid Level | Feature |
|---|---|
| 3 | Green Guardian, Green Knight Spells, Nature’s Cunning |
| 6 | Force of Nature |
| 10 | Forest Champion |
| 14 | Ever-Blooming Spirit |

---

### Level 3: Green Knight Spells

These spells are always prepared and do not count against your usual prepared spells. Non-Druid spells gained this way count as Druid spells for you.

| Druid Level | Spells |
|---|---|
| 3 | Aid, Bane, Ensaring Strike, Warding Bond |
| 5 | Life Transference, Spirit Shroud |
| 7 | Aura of Purity, Staggering Smite |
| 9 | Far Step, Circle of Power |

---

### Level 3: Green Guardian

You are a champion of the green and defender of all which grows.  

- **Unarmored Defense:** AC = 10 + Dex modifier + Wis modifier. You can still use a shield.  
- **Weapon Proficiency:** Proficient with all Martial Weapons and may wield metal weapons.  
- **Wisdom Weapon Attacks:** Use Wisdom modifier for attack and damage rolls with weapons.

---

### Level 3: Nature’s Cunning

- **Cunning Control:** When you cast a spell that pushes, pulls, or restrains a creature, you can make a melee weapon attack against that creature if within 5 ft. once per turn.  
- **Cunning Restoration:** As a bonus action, regain 1d4 + Wis modifier HP and make all attack rolls until the start of your next turn with advantage. Uses = Proficiency Bonus; recharge on a long rest.

---

### Level 6: Force of Nature

Summon a **Force of Nature** using one Wild Shape use. It acts on your initiative, follows commands, and is friendly to allies.

**Force of Nature Stats**  

- **Large Plant, Unaligned**  
- **AC:** 14 + PB  
- **HP:** 5 + (5 × Druid level)  
- **Speed:** 40 ft.  
- **STR 16 (+3), DEX 12 (+1), CON 16 (+3), INT 10 (0), WIS 14 (+2), CHA 8 (-1)**  
- **Saves:** STR + PB +3, WIS + PB +3  
- **Immunities:** Poison, Charmed, Exhaustion, Frightened  
- **Senses:** Darkvision 60 ft., Passive Perception 12  
- **Languages:** Understands all languages you know  

**Traits**  
- **Hit Dice:** d10 equal to Druid level  
- **Essence of Nature:** Healing spells heal double  
- **Seeds of Discord:** Melee attackers must succeed on STR save vs. DC 8 + PB + STR mod or become Restrained  

**Actions**  
- **Rend:** Melee weapon attack, reach 5 ft., one target, 2d4 + 3 + PB slashing damage  
- **Multiattack:** At Druid 14, makes two Rend attacks  

**Reactions**  
- **Ensnaring Rend:** Opportunity attack can impose Restrained on target  

**Other**  
- Can act as a mount, make extra attacks with your Attack action, remains until reduced to 0 HP, resummoned, or you die.

---

### Level 10: Forest Champion

- **Nature’s Cunning Upgrade:** HP restored = 1d10 + Wis + PB  
- **Martial Spellcasting:** When taking the Attack action, can cast a Druid cantrip as part of it once per round.

---

### Level 14: Ever-Blooming Spirit

- **Regeneration:** Regrow lost limbs or heal grievous wounds after a Long Rest  
- **Last Stand:** When reduced to 0 HP, use reaction to regain 4d8 HP and immediately Attack or cast a spell; recharge on long rest  
- **Rebirth via Force of Nature:** If you die while your Force of Nature is alive, you are reborn through it with its remaining HP