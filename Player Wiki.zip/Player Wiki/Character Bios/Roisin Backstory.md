Róisin was born in a small frontier village along the Sword Coast. Her early life was peaceful but fragile, shaped by the simple rhythms of village life and the teachings of her father and grandmother. Her mother was absent, a shadowy figure whose presence was hinted at but never fully revealed. Despite the calm, danger was never far; at the age of six, tragedy struck when her father was killed defending her and her grandmother from an unexpected attack. That night marked the end of Róisin’s childhood innocence and the beginning of a life tethered to loss and survival.

At twelve, Róisin discovered she possessed a latent magical power. Her grandmother, recognizing the signs of a heritage long kept secret, revealed that Róisin’s mother had been magical and tied to a clandestine shadow organization. This revelation reframed everything Róisin had believed about her family, and planted the first seeds of curiosity and purpose that would grow into her own magical path.

By the age of sixteen, her grandmother entrusted Róisin with a small, ornate box containing her mother’s belongings. Among these was a six-petaled Bloomheart necklace, which would serve as Róisin’s magical focus and a tangible connection to her mother’s hidden legacy. The necklace’s petals shimmered with distinct colors—blue, red, yellow, pink, white, and black—each hinting at the nature of the power Róisin would come to wield.

When she turned eighteen, her grandmother was slain by the Black Earth cult, leaving Róisin alone and bound by grief. In the years since, she has grown into her powers, learning to channel the magic of the Bloomheart pendant and to navigate the lingering threats that haunt the Sword Coast. At twenty-four, she stands as a determined sorcerer, her abilities tied to both her innate talent and the mysterious inheritance of her mother’s shadowed past.

Róisin’s life is deeply intertwined with the town of Phandalin, the elemental significance of the region, and the secrets of the Black Earth cult. She carries questions about her mother and the shadow organization that linger unanswered, and her journey is shaped by the interplay of legacy, vengeance, and the untapped potential of the Bloomheart necklace. Through it all, Róisin is driven by a protective streak, a desire to understand her heritage, and the quiet determination to uncover the truths hidden within the green magic she now commands.



# RÓISIN — EXPANDED LORE
*Character Background & DM Reference Document*
*Setting: Faerûn, 1491 DR | Age: 24 | Class: Bloomheart Sorcerer*

---

## I. WHO RÓISIN IS TODAY

Róisin stands at twenty-four years old in the Year of Scarlet Witch, 1491 DR. She is a young woman shaped entirely by absence — a father taken too soon, a mother who was never truly there, and a grandmother whose death left a wound that has not closed. She carries herself with a quiet, watchful determination, the kind forged not by confidence but by necessity. She has learned that the world removes people without warning, and so she has learned not to lean too heavily on anything that breathes.

Her magic is not academic. It was not taught to her by a master in a tower. It arrived in her blood like a fever, coaxed out by grief and desperation and the strange inheritance of a necklace left by a mother she never knew. She does not fully understand what she is capable of, and that uncertainty is both her greatest vulnerability and her most honest truth.

She is currently moving through the Dessarin Valley drawn by the same dark gravity that pulls all roads toward Red Larch — rumours of elemental cult activity, the Black Earth's fingerprints on her grandmother's death, and the faintest thread of something she cannot name that feels, inexplicably, like her mother.

---

## II. THE MOTHER — SIOFRA

> **DM NOTE:** The mother's name, history, and current status are entirely unknown to Róisin. Everything in this section is DM-facing only. Reveal at your own pace.

### Her Name & Origins

Her name is Siofra. She was born somewhere along the Sword Coast — the exact location is deliberately obscured even in her own mind, a precaution she took when she erased herself. She was not nobility, not a mage by training. She was a woman of unremarkable origins who stumbled into something ancient and extraordinary.

In her mid-twenties, Siofra was part of a small, loosely organised group of wanderers and scholars she called the Thornwoven — a name she gave to a fellowship of perhaps six or seven individuals who shared an obsession with old magic, pre-Sundering artefacts, and the places between civilisations where forgotten things collect dust. They were not a faction. They had no sigil or charter. They were simply people who found each other through the same curiosity.

It was through the Thornwoven that Siofra first encountered the Bloomheart necklace.

### The Discovery of the Bloomheart Necklace

The necklace was found in a collapsed merchant's cache beneath the ruins of a pre-Spellplague waystation on the edge of the Delimbiyr Vale — a site the Thornwoven had been excavating quietly for months. It appeared, at first glance, to be a piece of decorative jewellery. Unusual craftsmanship. Six petals, six distinct colours, each carved from a different material and set in silver so old it had gone nearly black.

The others in the Thornwoven dismissed it. Siofra could not. She felt something when she held it — not warmth exactly, but recognition. As though the necklace had been waiting.

Over the following years, through painstaking study and a kind of intuitive communion she never fully understood, Siofra unlocked the necklace's nature. It was not made. It was grown — a crystallised remnant of some ancient magical confluence, each petal a stable fragment of a different arcane current. The power within it did not respond to scholarly command. It responded to emotional resonance. To a living conduit.

Siofra became that conduit. She did not become a sorcerer in the classical sense — she became a vessel, the necklace's first true awakened bearer in what she estimated had been centuries. The magic she channelled was extraordinary and, at times, terrifying.

> **DM NOTE:** The necklace's true origins are intentionally left open for DM expansion. It predates the Spellplague and its exact history is unknown even to Siofra. It is not evil. It is not aligned. It is simply old, and alive in the way that very old things sometimes are.

### The Black Earth & What They Want

Word travels in the dark. The Black Earth cult — obsessed with the domination and weaponisation of earth and stone elemental power — became aware of the Bloomheart necklace through an informant embedded in the Thornwoven. What drew their interest was not the necklace's beauty or its market value. It was the black petal.

The black rose essence within the necklace — the one that bleeds its bearer when used — resonates at a frequency that Black Earth scholars believed could be reverse-engineered into a conduit for deep elemental corruption. In plain terms: they believed that if they could study and replicate the necklace's unlocking mechanism, they could use a similar principle to awaken and weaponise something far more dangerous buried beneath the Sumber Hills.

They were not entirely wrong. And that is what makes them dangerous.

When the cult made their move on Siofra and the Thornwoven, they did not come quietly. Most of the fellowship was killed or scattered. Siofra fled with the necklace. She was pregnant with Róisin at the time — though she did not yet know it.

### The Bargain & The Erasure

Siofra gave birth to Róisin in the frontier village where the story begins. She stayed long enough to see her daughter placed safely in the arms of her own mother — Róisin's grandmother — and then she made her choice.

She did not bargain with the cult. She did not bargain with any god or devil. The bargain she made was with herself, and it was this: she would disappear so completely that no thread of her existence could be followed back to Róisin. She would erase her name, her face in records, her connections, her history. She would become no one. A ghost moving through the world with no identity the cult could track.

She left the necklace. She left her daughter. She left everything she had ever been.

She has watched from a distance — through intermediaries she trusts absolutely, through the kind of surveillance only a woman with no identity and nothing to lose can maintain — as Róisin grew. She knows her daughter is alive. She knows she is travelling toward the Dessarin Valley. She knows the Black Earth killed her mother, Róisin's grandmother, deliberately — because the grandmother had begun asking questions, and the cult recognised the danger of a grandmother who knew too much and loved her granddaughter too fiercely to stay quiet.

Siofra has never forgiven herself for that death. She believes, probably correctly, that it is her fault.

> **DM NOTE:** Siofra is not a villain. She is a woman who made an impossible choice under terrible pressure and has been paying for it ever since. If Róisin ever finds her, she will not find a mother with answers and open arms. She will find a hollow woman who has spent twenty-four years becoming nothing — and who may not know how to become someone again. Handle with care. This reunion, if it comes, should cost something.

---

## III. THE GRANDMOTHER — WHAT SHE KNEW

Róisin's grandmother knew more than she ever told Róisin. She knew that Siofra had been involved in something dangerous. She knew the necklace was not ordinary. She had kept it hidden and kept her mouth shut for eighteen years out of love and pragmatism.

What changed was the weather. As elemental cult activity began to intensify across the Dessarin Valley and the Sword Coast, the grandmother began to recognise patterns — the same restless, wrongness in the earth that Siofra had once described to her in hushed tones before she vanished. She started asking questions of the wrong people. A merchant. A travelling priest. A man who turned out to be Black Earth.

The cult killed her not because she was a threat in any martial sense. They killed her because she was beginning to trace a line back to the necklace — and because eliminating her sent a message to anyone still watching: we have not forgotten.

What the grandmother did not know, and what no one has yet told Róisin, is that she left something behind. Hidden in the lining of the ornate box she gave Róisin alongside the necklace is a folded piece of parchment — a single name and a location, written in the grandmother's hand. It is not Siofra's current name. It is a contact name — someone the grandmother trusted, who may know where Siofra is.

> **DM NOTE:** The hidden parchment in the box is a slow-burn reveal. Róisin has had the box for years but may never have thought to check the lining carefully. A quiet moment, a perception check, or a conversation that leads her to look more closely could surface this. The contact named on the parchment is your hook to Siofra, and you control when and whether it fires.

---

## IV. THE BLOOMHEART NECKLACE — WHAT RÓISIN DOESN'T KNOW

Róisin knows the necklace belonged to her mother. She knows it is her magical focus. She knows the six petals and their colours and, through experience, their effects. What she does not know is the following:

### It is older than anyone she has ever met

The necklace predates the Spellplague. It predates most living memory. Siofra estimated it was at least a thousand years old when she found it. Its origins are not recorded anywhere Róisin has access to, and possibly not recorded anywhere at all.

### It has had other bearers

Siofra was not the first to unlock it — only the most recent. The necklace shows faint signs of old attunement if examined by someone with the right knowledge. Previous bearers are unknown, but the necklace carries a kind of residual memory. On rare occasions, in dreams, Róisin may glimpse fragments of lives that are not hers.

> **DM NOTE:** Use these dream fragments sparingly and never explain them outright. They are atmosphere and mystery, not exposition dumps.

### The black petal is the key

The Black Earth cult's interest centres specifically on the black petal — the Shadowmantle essence. They believe it contains a harmonic signature that, if isolated and amplified, could serve as a key to unlocking something buried deep beneath the Sumber Hills. What exactly is buried there is a question above Róisin's pay grade for now.

### It cannot be taken — only surrendered

The necklace does not respond to theft. Previous attempts to remove it from an unwilling bearer have resulted in the petal essences going dormant — the necklace becomes, to all detection, a mundane piece of jewellery. It only awakens for someone it recognises. This is why the cult wants Róisin alive, not dead. They need her to surrender it willingly, or they need to break her until she does.

---

## V. HOOKS & THREADS FOR 1491 DR

### The Hidden Parchment
Somewhere in the lining of the ornate box Róisin carries, a name and location wait to be found. This is the most direct thread to Siofra. The timing of discovery is entirely yours.

### Black Earth Awareness
The cult knows a Bloomheart bearer is moving through the Dessarin Valley. They do not yet know it is Siofra's daughter. When they find out — and they will — their interest will shift from tactical to deeply personal.

### Siofra Watching
Siofra is aware Róisin is in the region. Through her network of carefully maintained, identity-free contacts, she is monitoring her daughter's movements. She has not intervened. She is terrified of what happens if she does — both to Róisin and to herself. She is not ready to be a person again. But the closer Róisin gets to the truth, the harder it becomes to stay nothing.

### The Thornwoven Survivors
Not all members of the Thornwoven died when the Black Earth struck. One or two may still be alive — scattered, changed, carrying their own scars and their own pieces of the story. If the party encounters the right travelling scholar or the right bitter old wanderer, a fragment of Siofra's past could surface from an unexpected direction.

---

*For DM eyes only. Handle with care and patience.*
