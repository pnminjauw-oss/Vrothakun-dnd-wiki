

Born under the shadow of the Shata-Ar (Sun Tree) on the outskirts of Sildeyuir in The Year of Shining Waves (1139DR) -  Sylwen grew up amongst the love of her family amidst the throws of the chaotic beauty of the Feywilde.

A simple up-bringing amongst her Eladrin heritage was guided through the common knowledge of Elven lore, developing a natural aptitude in herbology,botany and alchemy from a young age.

In The Year of The Winged Worm (1225DR) an unexpected arrival changed the course of her future. 

Kaelen Varr, a grizzled but gentle ranger befriended her and seeing the spark of promise within Sylwen, took it upon himself to continue her education. This time focusing on honing her senses to the natural landscape around her -reading the wind, tracking a stag through rough terrain, listening to the language of the birds and plants. Sylwen became an adept hunter with skills surpassing most of her fellow Eladrin and her relationship with Kaelen ran deep.

In 1374DR(The Year of Lightning Storms) during the climax of the Fomorian revolt Kaelen, while leading a hunting party, was killed by the mutated Giants. Sylwen, being nearby, was unable to reach him as something within her snapped, a connection to the world around her inexplicably and suddenly disconnected. Having been pulled through the fabric of the Astral Sea Sylwen awakes in Yuirwood.

With the help of a visiting Sun-Elf (Araevin Teshurr) portals were found in Yuirwood which seemed to be connected to the Feywilde. After a decade or so Araevin was able to stabilize the portals granting access back to Fey from Faerun however a deep connection to Fey was required to travel through them. For reasons unclear however Sylwen could not use the portals to return home. Her connection to Fey had seemingly been severed. Sylwen has been traveling the wilds of Faerun since.

Fast forward to present time (1491DR). It’s been a little over a century since the events in Sildeyuir/Yuirwood and now, suddenly the weather has been unpredictable again. Violent lightning strikes, Summer snow storms and destructive earthquakes are appearing across the realm. Maybe, just maybe this is the missing piece Sylwen has been searching for. Maybe if she follows the storms to their origin she can find a way home. She reads the wind and listens to the waters. They tell her she must make her way to the Sjever Plateau and so, she does…



# Sylwen En'sKeth — Feyshot Conclave Rekindling
## "The Body Remembers"
### Location: Any Combat Encounter — DM Triggered

---

## A Note Before The Scene

Do not railroad this moment.
Do not script it.
Do not force it toward a specific encounter 
or a specific shot.

Sylwen's pilot lives in combat.
The moment will find her there naturally.

Your job is to recognize it when it arrives
and narrate it cleanly when it does.

That is all.

---

## What To Watch For

The trigger conditions are broad by design.
Any of the following qualify:

- A shot that should be difficult or impossible
  given current conditions — wind, distance,
  elevation, movement
- A moment where she is moving and shooting
  simultaneously without breaking stride
- A target that requires reading the environment
  rather than just aiming at it
- Any combat moment that asks something of her
  beyond standard archery
- A shot that makes someone at the table
  react out loud before they mean to

When you see it — that's the moment.

---

## The Internal Experience
### Narrate quietly to Sylwen's player after the shot lands

Not a decision.
Not a realization.
Not a vision or a voice or a memory.

Her hands did something before her mind approved it.

The shot left before she consciously chose to take it.
She was already breathing out.
Already adjusting for something —
wind speed, elevation, movement, angle —
that she shouldn't have been able to calculate that fast.

Kaelen Varr didn't teach her to think about the bow.

He taught her to become it.

That knowledge never left.
It went somewhere unreachable after the Fomorian revolt
severed her from everything familiar.

It just came back.
Not with fanfare.
Not with grief.
Not with his name on her lips.

Just — her hands knowing what to do
before the rest of her caught up.

---

## What The Party Sees

A shot that lands when it shouldn't have.

The specific quality of stillness in Sylwen
in the half second after it does.

Not dramatic. Not announced.
Just a half beat where something is different
about the way she's standing.

Then combat continues.

Someone at the table will say something.
They always do.
Let them.

---

## What Sylwen's Player Gets

No private note.
No speech.
No directed emotional beat.

Just the combat doing what combat does —
and her body remembering who she is inside it.

If her player notices the shift and leans into it
organically — wonderful.

If she just keeps fighting — also wonderful.
The rekindling doesn't require acknowledgment
to be real.

---

## Kaelen Varr — Present Without Being Named

He doesn't appear.
He doesn't speak.
He isn't in the shot as a vision or a ghost.

But he's in the mechanics of it.
The breathing. The adjustment.
The particular way the bow sits in her hands
when she stops thinking about it.

He built this into her over decades in the wilds
of Sildeyuir.
A century and a half ago.

The Fomorian revolt took everything else.
It didn't take this.

Do not name him in the moment.
Do not make it about him.

If Sylwen's player finds him in it later —
that belongs to her.

---

## Mechanical Manifestation

The Feyshot Conclave techniques don't
announce themselves with light or sound
or any outward marker.

Her first Trick Shot doesn't feel like
a new ability.

It feels like something she always knew
how to do.

Because it is.

---

## The Bigger Picture — DM Reference

Sylwen's true unlock moment is at level 7.
The Fey Court. The deeper Feywild connection.
The real weight of what was severed
and what it means to reach back toward it.

This moment is not that.

This is the door opening a crack.
Enough light to see by.
Not enough to see everything.

The bow remembers.
The Feywild is still a long way from here.

Save the rest for when it's earned.

---

## What This Moment Is NOT

- This is not about the Feywild. Not yet.
- This is not grief for Kaelen Varr.
  Not at this table, not with this pilot.
- This is not a realization or a speech
  or an emotional declaration.

It is a halfling ranger on a battlefield
whose hands stopped forgetting
something they were never supposed to forget.

That's enough.
That's everything.
