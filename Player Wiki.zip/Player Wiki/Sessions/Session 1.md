

## Summary
Clean recap of what happened.

## Key Events
- Major moments
- Discoveries
- Combat outcomes (no hidden mechanics)

## Notable NPCs
- [[NPC Name]]

## Locations Visited
- [[Location]]

## Loot / Rewards
- Items players received

## Unresolved Threads
- Open questions
- Leads to follow