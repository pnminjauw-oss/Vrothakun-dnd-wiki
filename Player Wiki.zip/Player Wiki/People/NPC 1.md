

## Overview


## Known Information
- What players know
- Public reputation
- Visible traits

## Relationships
- Connected to [[Faction]]
- Seen in [[Location]]

## Recent Activity
- Appeared in [[Session X]]

## Notes
Rumors, unclear details, or player speculation