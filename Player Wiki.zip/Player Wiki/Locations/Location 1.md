

## Overview
General description of the place.

## Notable Features
- Key landmarks
- Important details

## Inhabitants
- [[NPC Name]]
- [[Faction]]

## Related Events
- [[Session X]]

## Notes
Rumors or mysteries